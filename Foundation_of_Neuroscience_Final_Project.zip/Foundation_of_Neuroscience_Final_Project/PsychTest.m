Subject_Num = 1;
block_num = 1;
% Specify the file name
fileName = 'data_';
fileName = [fileName num2str(Subject_Num)];

% Check if the file exists
if exist(fileName, 'file') == 2
    % Load the struct from the MAT file
    try
        load(fileName);
        disp('Struct loaded successfully.');
    catch
        disp('Error loading the struct.');
    end
else
    
if Subject_Num == 1 
data_1(block_num).Num_Block = 0;
data_1(block_num).Accuracy_T = 0;
data_1(block_num).Accuracy_H = 0;
data_1(block_num).Accuracy_B = 0;
data_1(block_num).Accuracy_M = 0;
data_1(block_num).Accuracy_F = 0;
data_1(block_num).Firing_rate = 0;       
 elseif Subject_Num == 2
data_2(block_num).Num_Block = (0);
data_2(block_num).Accuracy_T = (0);
data_2(block_num).Accuracy_H = (0);
data_2(block_num).Accuracy_B = (0);
data_2(block_num).Accuracy_M = (0);
data_2(block_num).Accuracy_F = (0);
data_2(block_num).Firing_rate = (0);
 else
data_3(block_num).Num_Block = (0);
data_3(block_num).Accuracy_T = (0);
data_3(block_num).Accuracy_H = (0);
data_3(block_num).Accuracy_B = (0);
data_3(block_num).Accuracy_M = (0);
data_3(block_num).Accuracy_F = (0);
data_3(block_num).Firing_rate = (0);
end  
end






Screen('Preference', 'SkipSyncTests', 1);
% Initialize Psychtoolbox
PsychDefaultSetup(2);
% Screen parameters
screenNumber = max(Screen('Screens'));
[window, windowRect] = PsychImaging('OpenWindow', screenNumber, 0);
% Set the text properties
Screen('TextSize', window, 30);
Screen('TextColor', window, [255 255 255]);
% Load images
imageFolderPath = "D:\NueroScience\human\block_";
fullFileAddress = imageFolderPath +(block_num)+"\";
disp(fullFileAddress)
imageFiles = dir(fullfile(fullFileAddress, '*.jpg'));
imageAddresses = cell(numel(imageFiles), 1);
% Populate the cell array with full paths of the image files
for i = 1: numel(imageFiles)
    imageAddresses{i} = fullfile(fullFileAddress, imageFiles(i).name);
end

% imageFiles = {'D:\NueroScience\Medium\Tar\M_ani6.jpg', 'D:\NueroScience\Medium\Tar\M_ani15.jpg'};
numImages = length(imageAddresses);
white_cross_ad = 'D:\NueroScience\whiteCross.PNG';
black_cross_ad = 'D:\NueroScience\blackCross.PNG';
gray_ad = 'D:\NueroScience\Gray.PNG';

white_cross_image = imread(white_cross_ad);
black_cross_image = imread(black_cross_ad);
gray_image = imread(gray_ad);

targetSize = [256, 256];
% Resize the image
white_cross_image = imresize(white_cross_image, targetSize);
black_cross_image = imresize(black_cross_image, targetSize);
gray_image = imresize(gray_image, targetSize);

% Shuffle image order
shuffledOrder = randperm(numImages);

% Preallocate array to store responses
responses = zeros(1, numImages);
[xCenter, yCenter] = RectCenter(windowRect);

elapsedTimes = zeros(1, 120);
% Display images and collect responses
for i = 1:numImages
[xCenter, yCenter] = RectCenter(windowRect);
% Flip the screen to display the white fixation cross on gray background
    Screen('PutImage', window, white_cross_image);
    Screen('Flip', window);
    WaitSecs(0.5);  
    
    % Load the current image
    currentImage = imread(imageAddresses{shuffledOrder(i)});
    % Display the image for 20 milliseconds
    Screen('PutImage', window, currentImage);
    Screen('Flip', window);
    WaitSecs(0.02); % 20 milliseconds
    
    Screen('PutImage', window, white_cross_image);
    Screen('Flip', window);
    WaitSecs(0.03); 
    
    % Apply 1/f random noise mask
    filteredNoise = shuffledIm(currentImage); 
    Screen('PutImage', window, filteredNoise);
    Screen('Flip', window);
    WaitSecs(0.08);
    % Clear the screen
%     Screen('Flip', window);
    Screen('PutImage', window, black_cross_image);
    Screen('Flip', window);


    % Wait for response (1 for animal, 2 for non-animal)
 % Wait for response (1 for animal, 2 for non-animal) with a 2-second timeout
     startTime = tic;
    response = 2;
    while response == 2
        [keyIsDown, ~, keyCode] = KbCheck;
        if keyIsDown
            if keyCode(KbName('LeftArrow')) % Pressed '1' key
                response = 0;
            elseif keyCode(KbName('RightArrow')) % Pressed '2' key
                response = 1;
            end
        end
    end
    elapsedTimes(i) = toc(startTime);



    
    % Save the response in the array
    responses(i) = response;
    
end

% Display or save the entire responses array
disp('All responses:');
disp(responses);

% Close Psychtoolbox
sca;

r = trueLabels(imageFiles,shuffledOrder);
accuracy = sum(r == responses) / length(responses);
firing_rate = sum(responses) / length(responses);
[accuracy_H,accuracy_B,accuracy_M,accuracy_F] = accuracies(imageFiles,shuffledOrder,responses);

 if Subject_Num == 1 
data_1(block_num).Num_Block = (block_num);
data_1(block_num).Accuracy_T = (accuracy);
data_1(block_num).Accuracy_H = (accuracy_H);
data_1(block_num).Accuracy_B = (accuracy_B);
data_1(block_num).Accuracy_M = (accuracy_M);
data_1(block_num).Accuracy_F = (accuracy_F);
data_1(block_num).Firing_rate = (firing_rate); 
fileName = 'D:\NueroScience\human\data_1.mat';
save(fileName, 'data_1');

 elseif Subject_Num == 2
data_2(block_num).Num_Block = (block_num);
data_2(block_num).Accuracy_T = (accuracy);
data_2(block_num).Accuracy_H = (accuracy_H);
data_2(block_num).Accuracy_B = (accuracy_B);
data_2(block_num).Accuracy_M = (accuracy_M);
data_2(block_num).Accuracy_F = (accuracy_F);
data_2(block_num).Firing_rate = (firing_rate);
fileName = 'D:\NueroScience\human\data_2.mat';
save(fileName, 'data_2');
 else
     
data_3(block_num).Num_Block = (block_num);
data_3(block_num).Accuracy_T = (accuracy);
data_3(block_num).Accuracy_H = (accuracy_H);
data_3(block_num).Accuracy_B = (accuracy_B);
data_3(block_num).Accuracy_M = (accuracy_M);
data_3(block_num).Accuracy_F = (accuracy_F);
data_3(block_num).Firing_rate = (firing_rate);
fileName = 'D:\NueroScience\human\data_3.mat';
save(fileName, 'data_3');

 end


% Save the struct to a MAT file
    
function output_image = shuffledIm(original_image)
[rows, cols, channels] = size(original_image);
original_image_1d = reshape(original_image, [], channels);
perm_indices = randperm(rows * cols);
shuffled_image_1d = original_image_1d(perm_indices, :);
shuffled_image = reshape(shuffled_image_1d, [rows, cols, channels]);
output_image = shuffled_image;
end
 function output = trueLabels(imageFiles,shuffledOrder)
 temp = zeros(1,120);
 for i=1 : 120
       if startsWith(imageFiles(shuffledOrder(i)).name, 'B_')
           temp(i) = 1;
       elseif startsWith(imageFiles(shuffledOrder(i)).name, 'M_')
           temp(i) = 1;
       elseif startsWith(imageFiles(shuffledOrder(i)).name, 'F_')
           temp(i) = 1;       
       elseif startsWith(imageFiles(shuffledOrder(i)).name, 'H_')
           temp(i) = 1;   
       elseif startsWith(imageFiles(shuffledOrder(i)).name, 'Bdn_')
           temp(i) = 0;
       elseif startsWith(imageFiles(shuffledOrder(i)).name, 'Bda_')
           temp(i) = 0;
       elseif startsWith(imageFiles(shuffledOrder(i)).name, 'Fda_')
           temp(i) = 0;
       elseif startsWith(imageFiles(shuffledOrder(i)).name, 'Fdn_')
           temp(i) = 0;
       elseif startsWith(imageFiles(shuffledOrder(i)).name, 'Hda_')
           temp(i) = 0;
       elseif startsWith(imageFiles(shuffledOrder(i)).name, 'Hdn_')
           temp(i) = 0;
       elseif startsWith(imageFiles(shuffledOrder(i)).name, 'Mdn_')
           temp(i) = 0;
       else
           temp(i) = 0;
       end          
 end
output = temp;
 end
    
 
 function [accuracy_H,accuracy_B,accuracy_M,accuracy_F] = accuracies(imageFiles,shuffledOrder,responses)
trueLabel_H = zeros(1,30);
response_H = zeros(1,30);
H = 0;
trueLabel_B = zeros(1,30);
response_B = zeros(1,30);
B = 0;
trueLabel_M = zeros(1,30);
response_M = zeros(1,30);
M = 0;
trueLabel_F = zeros(1,30);
response_F = zeros(1,30);
F = 0;
t = 0;
 for i=1 : 120
     t = t + 1;  
       if startsWith(imageFiles(shuffledOrder(i)).name, 'B_')
           B = B + 1;
           trueLabel_B(B) = 1;
           response_B(B) = responses(i);
       elseif startsWith(imageFiles(shuffledOrder(i)).name, 'M_')
           M = M + 1;
           trueLabel_M(M) = 1;
           response_M(M) = responses(i);
       elseif startsWith(imageFiles(shuffledOrder(i)).name, 'F_')
           F = F + 1;
           trueLabel_F(F) = 1;
           response_F(F) = responses(i);     
       elseif startsWith(imageFiles(shuffledOrder(i)).name, 'H_')
           H = H + 1;
           trueLabel_H(H) = 1;
           response_H(H) = responses(i);  
       elseif startsWith(imageFiles(shuffledOrder(i)).name, 'Bdn_')
           B = B + 1;
           trueLabel_B(B) = 0;
           response_B(B) = responses(i);
       elseif startsWith(imageFiles(shuffledOrder(i)).name, 'Bda_')
           B = B + 1;
           trueLabel_B(B) = 0;
           response_B(B) = responses(i);
       elseif startsWith(imageFiles(shuffledOrder(i)).name, 'Fda_')
           F = F + 1;
           trueLabel_F(F) = 0;
           response_F(F) = responses(i);
       elseif startsWith(imageFiles(shuffledOrder(i)).name, 'Fdn_')
           F = F + 1;
           trueLabel_F(F) = 0;
           response_F(F) = responses(i);
       elseif startsWith(imageFiles(shuffledOrder(i)).name, 'Hda_')
           H = H + 1;
           trueLabel_H(H) = 0;
           response_H(H) = responses(i);
       elseif startsWith(imageFiles(shuffledOrder(i)).name, 'Hdn_')
           H = H + 1;
           trueLabel_H(H) = 0;
           response_H(H) = responses(i);
       elseif startsWith(imageFiles(shuffledOrder(i)).name, 'Mdn_')
           M = M + 1;
           trueLabel_M(M) = 0;
           response_M(M) = responses(i);
       else
           M = M + 1;
           trueLabel_M(M) = 0;
           response_M(M) = responses(i);
       end          
 end

 accuracy_H = sum(trueLabel_H == response_H) / length(response_H);
 accuracy_B = sum(trueLabel_B == response_B) / length(response_B);
 accuracy_M = sum(trueLabel_M == response_M) / length(response_M);
 accuracy_F = sum(trueLabel_F == response_F) / length(response_F);
     end