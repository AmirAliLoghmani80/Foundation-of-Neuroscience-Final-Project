%demoRelease.m
%demonstrates how to use C2 standard model features in a pattern classification framework

addpath D:\ترم 7\Courses\Neuro\New folder\hmax- Code\standardmodelmatlabrelease\osu-svm %put your own path to osusvm here

useSVM = 1; %if you do not have osusvm installed you can turn this
            %to 0, so that the classifier would be a NN classifier
	    %note: NN is not a great classifier for these features
	    
READPATCHESFROMFILE = 0; %use patches that were already computed
                         %(e.g., from natural images)

patchSizes = [4 8 12 16]; %other sizes might be better, maybe not
                          %all sizes are required
			  
numPatchSizes = length(patchSizes);

%specify directories for training and testing images
train_set.pos   = 'D:\NueroScience\newTrainTestSets\Train\Target';
train_set.neg   = 'D:\NueroScience\newTrainTestSets\Train\Distractor';
test_set.pos    = 'D:\NueroScience\newTrainTestSets\Test\Target';
test_set.neg    = 'D:\NueroScience\newTrainTestSets\Test\Distractor';

cI = readAllImages(train_set,test_set); %cI is a cell containing
                                        %all training and testing images

if isempty(cI{1}) | isempty(cI{2})
  error(['No training images were loaded -- did you remember to' ...
	' change the path names?']);
end
  
%below the c1 prototypes are extracted from the images/ read from file
if ~READPATCHESFROMFILE
  tic
  numPatchesPerSize = 250; %more will give better results, but will
                           %take more time to compute
  cPatches = extractRandC1Patches(cI{1}, numPatchSizes, ...
      numPatchesPerSize, patchSizes); %fix: extracting from positive only 
                                      
  totaltimespectextractingPatches = toc;
else
  fprintf('reading patches');
  cPatches = load('PatchesFromNaturalImages250per4sizes','cPatches');
  cPatches = cPatches.cPatches;
end

%----Settings for Testing --------%
rot = [90 -45 0 45];
c1ScaleSS = [1:2:18];
RF_siz    = [7:2:39];
c1SpaceSS = [8:2:22];
minFS     = 7;
maxFS     = 39;
div = [4:-.05:3.2];
Div       = div;
%--- END Settings for Testing --------%

fprintf(1,'Initializing gabor filters -- full set...');
%creates the gabor filters use to extract the S1 layer
[fSiz,filters,c1OL,numSimpleFilters] = init_gabor(rot, RF_siz, Div);
fprintf(1,'done\n');

%The actual C2 features are computed below for each one of the training/testing directories
tic
for i = 1:4,
  C2res{i} = extractC2forcell(filters,fSiz,c1SpaceSS,c1ScaleSS,c1OL,cPatches,cI{i},numPatchSizes);
  toc
end
totaltimespectextractingC2 = toc;

%Simple classification code
XTrain = [C2res{1} C2res{2}]; %training examples as columns 
XTest =  [C2res{3},C2res{4}]; %the labels of the training set
ytrain = [ones(size(C2res{1},2),1);-ones(size(C2res{2},2),1)];%testing examples as columns
ytest = [ones(size(C2res{3},2),1);-ones(size(C2res{4},2),1)]; %the true labels of the test set
% if useSVM
%   Model = CLSosusvm(XTrain,ytrain);  %training
%   [ry,rw] = CLSosusvmC(XTest,Model); %predicting new labels
% else %use a Nearest Neighbor classifier
%   Model = CLSnn(XTrain, ytrain); %training
%   [ry,rw] = CLSnnC(XTest,Model); %predicting new labels
% end  
% successrate = mean(ytest==ry) %a simple classification score

svmModel = fitcsvm(XTrain', ytrain);
predictedLabels = predict(svmModel, XTest');
accuracy = sum(predictedLabels == ytest) / numel(ytest);
[acc_H,acc_B,acc_M,acc_F] = accuracies_devided(ytest,predictedLabels);

function [acc_H,acc_B,acc_M,acc_F] = accuracies_devided(ytest,predictedLabels)

B_test = ytest(1:75);
Bd_test = ytest(301:375);
B_pred = predictedLabels(1:75);
Bd_pred = predictedLabels(301:375);
result_B = [B_test; Bd_test];
result_B_pred = [B_pred; Bd_pred];
F_test = ytest(76:150);
Fd_test = ytest(376:450);
F_test_pred = predictedLabels(76:150);
Fd_test_pred = predictedLabels(376:450);
result_F = [F_test; Fd_test];
result_F_pred = [F_test_pred; Fd_test_pred];
H_test = ytest(151:225);
Hd_test = ytest(451:525);
H_test_pred = predictedLabels(151:225);
Hd_test_pred = predictedLabels(451:525);
result_H = [H_test; Hd_test];
result_H_pred = [H_test_pred; Hd_test_pred];
M_test = ytest(226:300);
Md_test = ytest(526:600);
M_test_pred = predictedLabels(226:300);
Md_test_pred = predictedLabels(526:600);
result_M = [M_test; Md_test];
result_M_pred = [M_test_pred; Md_test_pred];



acc_H = sum(result_H_pred == result_H) / numel(result_H);
acc_B = sum(result_B_pred == result_B) / numel(result_B);
acc_M = sum(result_M_pred == result_M) / numel(result_M);
acc_F = sum(result_F_pred == result_F) / numel(result_F);

end

